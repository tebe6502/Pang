//----------------------------------------------------------------------------
// RMT Merge - helps merge multiple RMT text files into a single song.
// version 1.1 (January 5, 2011)
//
// rmtmerge.cpp
// Copyright 2011 Mark Schmelzenbach (gauntman)
//
//----------------------------------------------------------------------------
#include <vector>
#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>
#include <set>
#include <map>
#include <strstream>

#include <boost/algorithm/string.hpp>
#include <boost/algorithm/string/regex.hpp>
#include <boost/format.hpp>

#include "sha1.h"

typedef std::vector<std::string> SplitVector;

//----------------------------------------------------------------------------
//! Chunks contain all information for modules, songs, tracks, intruments
/*! This class treats much of the information as black box
*/
class Chunk {
public:
  void Dump(std::ostream &out) {
    out<<name<<"\n"<<identifier<<comment<<block<<"\n";
    const char *look=block.c_str();
    look+=block.length()-1;
    if (*look!='\n') {
      out<<"\n";
    }
  }

  std::string name;  ///< chunk type name, i.e. [SONG]
  std::string identifier; ///< string identifier for TRACK and INSTRUMENT
  std::string comment; ///< INSTUMENT name
  std::string block; ///< chunk body
  std::string hash;  ///< SHA1 hash of body for duplicate testing
};

//----------------------------------------------------------------------------
//  SaveSong
//  Save out the song chunks
//! \param fname the name of the file to save
//! \param song the song to process
//! \return boolean flag indicating success
//----------------------------------------------------------------------------
bool SaveSong(const char *fname, const std::vector<Chunk *> &song) {
  std::ofstream out(fname);
  int len=song.size();
  const char *order[]={"[MODULE]","[SONG]","[INSTRUMENT]","[TRACK]"};
  for(int tp=0;tp<4;tp++) {
    std::string stp=order[tp];
    for(int i=0;i<len;i++) {
      if (song[i]->name==stp) {
        song[i]->Dump(out);
      }
    }
  }
  out.close();
  return true;
}

//----------------------------------------------------------------------------
//  GetMaxima
//  Find the maximum track and instrument numbers
//! \param song the song to process
//! \param[out] maxTrack returns the maximum referenced track number
//! \param[out] maxInstrument returns the maximum referenced instrument number
//! \return boolean flag indicating success
//----------------------------------------------------------------------------
bool GetMaxima(const std::vector<Chunk *> &song, int &maxTrack, int &maxInstrument) {
  std::vector<Chunk *>::const_iterator walk;
  maxTrack=maxInstrument=-1;

  walk=song.begin();
  while(walk!=song.end()) {
    Chunk *look=*walk;
    if (look->name=="[TRACK]") {
      const char *begin;
      char *err=NULL;

      begin=look->identifier.c_str();
      int num=(int)strtol(begin,&err,16);
      if ((err!=begin)&&(num>maxTrack)) {
        maxTrack=num;
      }
    } else if (look->name=="[INSTRUMENT]") {
      const char *begin;
      char *err=NULL;

      begin=look->identifier.c_str();
      int num=(int)strtol(begin,&err,16);
      if ((err!=begin)&&(num>maxInstrument)) {
        maxInstrument=num;
      }
    }
    ++walk;
  }
  return true;
}

//----------------------------------------------------------------------------
//  ChangeTracks
//  Update track references in song chunks
//! \param[in/out] song the song to process
//! \param remap map containing from:to pairs of strings
//! \return boolean flag indicating success
//----------------------------------------------------------------------------
bool ChangeTracks(std::vector<Chunk *> &song, std::map<std::string,std::string> remap) {
  std::vector<Chunk *>::iterator walk;

  walk=song.begin();
  while(walk!=song.end()) {
    Chunk *look=*walk;
    if (look->name=="[SONG]") {
      std::set<std::string> trackRefs, instrumentRefs;
      std::istrstream in(look->block.c_str());
      std::string buf,line;
      while(std::getline(in,line)) {
        if (line[0]!='G') {
          SplitVector splitLine;
          boost::split(splitLine, line, boost::is_any_of(" "), boost::token_compress_on);
          line.clear();
          for(unsigned int i=0;i<splitLine.size();i++) {
            std::map<std::string,std::string>::iterator check;
            check=remap.find(splitLine[i]);
            if (check!=remap.end()) {
              line+=check->second+" ";
            } else {
              line+=splitLine[i]+" ";
            }
          }
          boost::trim(line);
          line+="\n";
        } else {
          line+="\n";
        }
        buf+=line;
      }
      boost::trim(buf);
      look->block=buf;
    } else if (look->name=="[TRACK]") {
      std::map<std::string,std::string>::iterator check;
      check=remap.find(look->identifier);
      if (check!=remap.end()) {
        look->identifier=check->second;
      }
    }
    ++walk;
  }
  return true;
}

//----------------------------------------------------------------------------
//  RemoveUnusedItems
//  Remove unused [INSTRUMENT] and [TRACK] chunks
//! \param[in/out] song the song to process
//! \return boolean flag indicating success
//----------------------------------------------------------------------------
bool RemoveUnusedItems(std::vector<Chunk *> &song) {
  int rmTracks,rmInstruments;
  std::set<std::string> trackRefs, instrumentRefs, allTracks;
  std::map<std::string,std::string> empty;
  bool found=false;

  rmTracks=rmInstruments=0;
  for(unsigned int i=0;i<song.size();i++) {
    if (song[i]->name=="[SONG]") {
      std::istrstream in(song[i]->block.c_str());
      std::string line;
      while(std::getline(in,line)) {
        if (line[0]!='G') {
          SplitVector splitLine;
          boost::split(splitLine, line, boost::is_any_of(" "), boost::token_compress_on);
          for(unsigned int i=0;i<splitLine.size();i++) {
            trackRefs.insert(splitLine[i]);
          }
        }
      }
      found=true;
    } else if (song[i]->name=="[TRACK]") {
      allTracks.insert(song[i]->identifier);
    }
  }
  if (!found)
    return false;

  std::vector<Chunk *>::iterator reap;
  reap=song.begin();
  while(reap!=song.end()) {
    if ((*reap)->name=="[TRACK]") {
      // check track id
      if (trackRefs.find((*reap)->identifier)==trackRefs.end()) {
        rmTracks++;
        delete *reap;
        reap=song.erase(reap);
        continue;
      }
    }
    ++reap;
  }

  for(unsigned int i=0;i<song.size();i++) {
    if (song[i]->name=="[TRACK]") {
      std::istrstream in(song[i]->block.c_str());
      std::string line;
      while(std::getline(in,line)) {
        SplitVector split;
        boost::split(split, line, boost::is_any_of(" "), boost::token_compress_on);
        if (split.size()==3) {
          instrumentRefs.insert(split[1]);
        }
      }
    }
  }

  reap=song.begin();
  while(reap!=song.end()) {
    if ((*reap)->name=="[INSTRUMENT]") {
      // check track id
      if (instrumentRefs.find((*reap)->identifier)==instrumentRefs.end()) {
        delete *reap;
        rmInstruments++;
        reap=song.erase(reap);
        continue;
      }
    }
    ++reap;
  }

  std::set<std::string>::const_iterator walk,check;
  for(walk=trackRefs.begin();walk!=trackRefs.end();++walk) {
    check=allTracks.find(*walk);
    if (check==allTracks.end()) {
      empty.insert(std::make_pair(*walk,"--"));
    }
  }
  if (!empty.empty()) {
    ChangeTracks(song,empty);
    std::cerr<<"  Replaced "<<empty.size()<<" undefined tracks with empty.\n";
  }

  std::cout<<"  Removed "<<rmInstruments<<" unused instruments, "<<rmTracks<<" unused tracks.\n";

  return true;
}

//----------------------------------------------------------------------------
//  ChangeInstruments
//  Update instruments on song tracks
//! \param[in/out] song the song to process
//! \param remap map containing from:to pairs of strings
//! \return boolean flag indicating success
//----------------------------------------------------------------------------
bool ChangeInstruments(std::vector<Chunk *> &song, std::map<std::string,std::string> remap) {
  std::vector<Chunk *>::iterator walk;

  walk=song.begin();
  while(walk!=song.end()) {
    Chunk *track=*walk;
    if (track->name=="[TRACK]") {
      std::istrstream in(track->block.c_str());
      std::string line, buf;
      while(std::getline(in,line)) {
        SplitVector split;
        boost::split(split, line, boost::is_any_of(" "), boost::token_compress_on);
        if (split.size()==3) {
          std::map<std::string,std::string>::iterator look;
          look=remap.find(split[1]);
          if (look!=remap.end()) {
            split[1]=look->second;
          }
          line=split[0]+" "+split[1]+" "+split[2]+"\n";
        } else {
          line+="\n";
        }
        buf+=line;
      }
      track->block=buf;
    }
    ++walk;
  }
  return true;
}

//----------------------------------------------------------------------------
//  RemapInstruments
//  Renumber instruments to begin at baseID.  This will upate track chunks and
//  instrument chunks as appropriate
//! \param[in/out] song the song to process
//! \param baseID the base number to start instrument renumbering at
//! \return boolean flag indicating success
//----------------------------------------------------------------------------
bool RemapInstruments(std::vector<Chunk *> &song, int baseID) {
  std::vector<Chunk *>::iterator walk;
  std::set<int> used;

  walk=song.begin();
  while(walk!=song.end()) {
    Chunk *look=*walk;
    if (look->name=="[INSTRUMENT]") {
      const char *begin;
      char *err=NULL;

      begin=look->identifier.c_str();
      int num=(int)strtol(begin,&err,16);
      if (err!=begin) {
        used.insert(num);
      }
    }
    ++walk;
  }

  std::set<int>::iterator update;
  std::map<std::string,std::string> remap;
  char buf[16];
  std::string start,end;
  for(update=used.begin();update!=used.end();++update) {
    if (*update!=baseID) {
      std::ostrstream out(buf,16);
      out<<boost::format("%2%") %1 %boost::io::group(std::uppercase,std::setfill('0'),std::hex,std::setw(2),*update)<<(char)0;
      start=buf;
      out=std::ostrstream(buf,16);
      out<<boost::format("%2%") %1 %boost::io::group(std::uppercase,std::setfill('0'),std::hex,std::setw(2),baseID)<<(char)0;
      end=buf;
      ++baseID;
      remap.insert(std::make_pair(start,end));
    } else {
      ++baseID;
    }
  }
  if (!ChangeInstruments(song,remap))
    return false;

  walk=song.begin();
  while(walk!=song.end()) {
    Chunk *look=*walk;
    if (look->name=="[INSTRUMENT]") {
      std::map<std::string,std::string>::iterator check;
      check=remap.find(look->identifier);
      if (check!=remap.end()) {
        look->identifier=check->second;
      }
    }
    ++walk;
  }
  return true;
}

//----------------------------------------------------------------------------
//  RemapTracks
//  Renumber tracks to begin at baseID.  This will upate track chunks and
//  song chunks as appropriate
//! \param[in/out] song the song to process
//! \param baseID the base number to start track renumbering at
//! \return boolean flag indicating success
//----------------------------------------------------------------------------
bool RemapTracks(std::vector<Chunk *> &song, int baseID) {
  std::vector<Chunk *>::iterator walk;
  std::set<int> used;

  walk=song.begin();
  while(walk!=song.end()) {
    Chunk *look=*walk;
    if (look->name=="[TRACK]") {
      const char *begin;
      char *err=NULL;

      begin=look->identifier.c_str();
      int num=(int)strtol(begin,&err,16);
      if (err!=begin) {
        used.insert(num);
      }
    }
    ++walk;
  }

  std::set<int>::iterator update;
  std::map<std::string,std::string> remap;
  char buf[16];
  std::string start,end;
  for(update=used.begin();update!=used.end();++update) {
    if (*update!=baseID) {
      std::ostrstream out(buf,16);
      out<<boost::format("%2%") %1 %boost::io::group(std::uppercase,std::setfill('0'),std::hex,std::setw(2),*update)<<(char)0;
      start=buf;
      out=std::ostrstream(buf,16);
      out<<boost::format("%2%") %1 %boost::io::group(std::uppercase,std::setfill('0'),std::hex,std::setw(2),baseID)<<(char)0;
      end=buf;
      ++baseID;
      remap.insert(std::make_pair(start,end));
    } else {
      ++baseID;
    }
  }

  ChangeTracks(song,remap);

  return true;
}

//----------------------------------------------------------------------------
//  RemoveDuplicateInstruments
//  Check the SHA hashes for instrument definitions and remove duplicates,
//  renumbering instruments when completed.  This will combine instruments
//  that have the same definitions, even if they have different names.
//  Also removes duplicate modules
//! \param[in/out] song the song to process
//! \return boolean flag indicating success
//----------------------------------------------------------------------------
bool RemoveDuplicateInstruments(std::vector<Chunk *> &song) {
  std::map<std::string,std::string> id,remap;
  std::vector<Chunk *>::iterator walk;
  std::map<std::string,std::string>::iterator check;

  walk=song.begin();
  while(walk!=song.end()) {
    Chunk *look=*walk;
    if (look->name=="[INSTRUMENT]") {
      check=id.find(look->hash);
      if (check!=id.end()) {
        remap.insert(std::make_pair(look->identifier,check->second));
        delete look;
        walk=song.erase(walk);
        continue;
      } else {
        id.insert(std::make_pair(look->hash,look->identifier));
      }
    } else if (look->name=="[MODULE]") {
      check=id.find(look->hash);
      if (check!=id.end()) {
        delete look;
        walk=song.erase(walk);
        continue;
      } else {
        id.insert(std::make_pair(look->hash,look->identifier));
      }
    }
    ++walk;
  }

  if (remap.size()) {
    std::cerr<<"Removing "<<remap.size()<<" duplicate instruments in merged song.\n";
    ChangeInstruments(song,remap);
    RemapInstruments(song,0);
  }
  return true;
}

//----------------------------------------------------------------------------
//  MergeSongs
//  Combine song blocks, updating Goto lines as appropriate
//! \param[in/out] song the song to process
//! \return boolean flag indicating success
//----------------------------------------------------------------------------
bool MergeSongs(std::vector<Chunk *> &song) {
  Chunk *firstSong=NULL;
  std::string block;
  int lines=0;
  std::vector<Chunk *>::iterator walk;
  std::map<std::string,std::string>::iterator check;

  walk=song.begin();
  while(walk!=song.end()) {
    if ((*walk)->name=="[SONG]") {
      if (!firstSong) {
        std::string line;

        firstSong=*walk;
        std::istrstream in(firstSong->block.c_str());
        block=firstSong->block;
        while(std::getline(in,line)) {
          lines++;
        }
        block+="\n";
      } else {
        std::string line;
        std::istrstream in((*walk)->block.c_str());
        int startLine=lines;
        while(std::getline(in,line)) {
          lines++;
          if (line[0]=='G') {
            std::string g=line.substr(0,11);
            if (g=="Go to line ") {
              char buf[16];
              const char *begin;
              char *err=NULL;
              begin=line.c_str();
              begin+=10;
              int num=(int)strtol(begin,&err,16);
              if (err!=begin) {
                num+=startLine;
                std::ostrstream out(buf,16);
                out<<boost::format("%2%") %1 %boost::io::group(std::uppercase,std::setfill('0'),std::hex,std::setw(2),num)<<(char)0;
                line="Go to line ";
                line+=buf;
              }
            }
          }
          line+="\n";
          block+=line;
        }
        delete *walk;
        walk=song.erase(walk);
        continue;
      }
    }
    ++walk;
  }
  firstSong->block=block;
  return true;
}

//----------------------------------------------------------------------------
//  BuildChunks
//  Chop an RMT string into chunks based on headers [MODULE], [SONG],
//  [INSTRUMENT] and [TRACK]
//! \param body the string to chunk
//! \param[out] chunks the resulting chunks
//! \return boolean flag indicating success
//----------------------------------------------------------------------------
bool BuildChunks(std::string body, std::vector<Chunk *> &chunks) {
  boost::regex e1("^(\\[(?:(?:MODULE)|(?:SONG)|(?:INSTRUMENT)|(?:TRACK))])$");
  chunks.clear();
  SplitVector split, splitType;

  boost::split_regex(split, body, e1);
  boost::find_all_regex(splitType, body, e1);
  if (split.size()>0) {
    split.erase(split.begin());
    int len=split.size();
    for(int i=0;i<len;i++) {
      unsigned char hash[20];
      char hexstring[41];
      boost::trim(split[i]);
      Chunk *chunk=new Chunk;
      chunk->name=splitType[i];
      chunk->block=split[i];

      if (chunk->name=="[TRACK]") {
        std::istrstream in(split[i].c_str());
        std::string line;
        std::getline(in,line);

        SplitVector splitLine;
        boost::split(splitLine, line, boost::is_any_of(" "), boost::token_compress_on);
        if (splitLine.size()==2) {
          chunk->identifier=splitLine[0];
          chunk->block=split[i].substr(chunk->identifier.size(),split[i].size()-chunk->identifier.size());
        }
      } else if (chunk->name=="[INSTRUMENT]") {
        std::istrstream in(split[i].c_str());
        std::string line;
        std::getline(in,line);

        SplitVector splitLine;
        boost::split(splitLine, line, boost::is_any_of(":"), boost::token_compress_on);
        if (splitLine.size()>=2) {
          chunk->identifier=splitLine[0];
          for(unsigned int i=1;i<splitLine.size();i++) {
            chunk->comment+=":";
            chunk->comment+=splitLine[i];
          }
        } else {
          chunk->identifier=line;
        }
        chunk->block=split[i].substr(chunk->identifier.size()+chunk->comment.size(),split[i].size()-(chunk->identifier.size()+chunk->comment.size()));
      }
      sha1::calc(chunk->block.c_str(),chunk->block.length(),hash);
      sha1::toHexString(hash, hexstring);
      chunk->hash=hexstring;
      chunks.push_back(chunk);
    }
    RemoveUnusedItems(chunks);
    RemapInstruments(chunks,0);
    RemapTracks(chunks,0);
    return true;
  }
  return false;
}

//----------------------------------------------------------------------------
//  main
//  main entry point - nothing surprising here
//! \param argc number of arguments
//! \param argv argument vector
//! \return error code, or 0 if success
//----------------------------------------------------------------------------
int main(int argc, char *argv[]) {
  std::string path;
  std::vector<Chunk *> mergedSong;

  if (argc<2) {
    std::cerr<<"RMTMerge v1.1 - RMT Text merging utility\n";
    std::cerr<<"  Usage: '"<<argv[0]<<"' song1.rmt.txt [song2.rmt.txt ... songN.rmt.txt]\n";
    return 1;
  }

  for(int i=1;i<argc;i++) {
    std::ifstream in;
    std::string file=argv[i];
    in.open(path+file);
    if (in.fail()) {
      std::cerr<<"Cannot open text rmt file: '"<<path<<file<<"'.\n";
      continue;
    }

    std::cerr<<"Reading '"+file+"'\n";
    std::vector<Chunk *> song;
    std::string buf,line;
    while(std::getline(in,line)) {
      line+="\n";
      buf+=line;
    }
    in.close();

    BuildChunks(buf,song);
    if (i>1) {
      int maxTrack, maxInstrument;
      GetMaxima(mergedSong,maxTrack,maxInstrument);
      RemapTracks(song,maxTrack+1);
      RemapInstruments(song,maxInstrument+1);
    }
    mergedSong.reserve(mergedSong.size()+song.size());
    mergedSong.insert(mergedSong.end(),song.begin(),song.end());
  }

  if (mergedSong.size()) {
    RemoveDuplicateInstruments(mergedSong);
    MergeSongs(mergedSong);

    SaveSong("merged.rmt.txt",mergedSong);
    std::cerr<<"Done.\n\nMerged file saved as 'merged.rmt.txt'\n";
  } else {
    std::cerr<<"No RMT files found.\n";
  }
  return 0;
}
