RMT Merge v1.1
==============

rmtmerge is a utility that helps merge multiple RMT txt files into a single song file.
Although much of the process is automated, there may be some manual clean-up required
before RMT will load the new file.


Windows Installation
====================
Unzip the archive.  If you do not have MSVC2010 Runtime components already installed on
your system, you will receive the following error:  "This application has failed to start
because MSVCR100.dll was not found. Re-installing the application may fix this problem."

If so, you will need to download and install the following package from Microsoft:
http://www.microsoft.com/downloads/en/details.aspx?displaylang=en&FamilyID=a7b7a05e-6de6-4d3a-a423-37bf0912db84

Linux/MacOSX Installation
=========================
You will need to build the tool from source.  The source has dependencies on the Boost
libraries, which may need to be installed on your system.

Basic Usage
===========
First, load each of the RMT files you wish to merge into RMT, and then save as rmt .txt
files ("TXT song files").  rmtmerge only works on rmt.txt formatted files, not on
native rmt files.  Once you have saved all of the files you intentend to merge, run
the following command line:

rmtmerge file1 file2 file3 file4

This will load all the files on the command line, merge them, and save the result as
merged.rmt.txt

Next, load the merged.rmt.txt file in a text editor and remove any extraneous [MODULE]
sections (there should only be one in a legal rmt.txt file).

Finally, load the file in RMT, go to the Song menu, select "All size optimizations",
and enjoy!

Details
=======
rmtmerge loads each rmt.txt file in turn.  First, it breaks apart the file into
individual sections of type MODULE, SONG, INSTRUMENT or TRACK.  Then, it analyzes the
SONG section and removes any TRACKS not referenced in the SONG.  Next, it checks each
TRACK section and removes any INSTRUMENTS that are not referenced.  Finally, it
renumbers the tracks and instruments starting at ID 0.

When merging files, rmtmerge will initially renumber tracks and instruments so that
there are no overlaps between files.  Then it examines each of the INSTRUMENT sections,
looking for duplicate definitions.  (Note: rmtmerge only considers the parameters, not
the instrument name or number.  This means that if two instruments have the same
definition, but one is called "Snare" and the other "Cool Snare", they will be considered
duplicates).  Duplicate instrument definitions will be merged.

Song sections will be merged, in order they were listed on the command line, updating
"Go to line" commands as necessary.

Finally, the merged song will be saved.

Things RMTMERGE Does Not Do
===========================
This tool deliberately does not merge MODULE sections (unless they are also identical).
This is to serve as a reminder about speed changes, etc.  You need to edit the final
file so that there is only one [MODULE] section!

Also, duplicate tracks are not merged.  RMT's native optimizer handles this case very
well, and you will probably want to run this in any case.

Legal Notices
=============
RMTMerge includes a SHA1 hashing implementation under the following license:

SHA1 Hashing code
Copyright (c) 2009, Micael Hildenborg
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:
    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in the
      documentation and/or other materials provided with the distribution.
    * Neither the name of Micael Hildenborg nor the
      names of its contributors may be used to endorse or promote products
      derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY Micael Hildenborg ''AS IS'' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL Micael Hildenborg BE LIABLE FOR ANY
DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

History
=======
January 3, 2011 -- v1.0, Initial Release
January 5, 2011 -- v1.1, Fixed song references to undefined tracks, marking
                         them as empty.

