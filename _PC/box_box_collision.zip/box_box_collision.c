#include <stdint.h>

struct	SBox
{
	uint8_t	x, y;
	uint8_t	width, height;
};

/**	Box - box collision test.
	@param	SBox* sbox	- Prostokat otaczajacy statyczny obiekt (murek).
	@param SBox* old_dbox - Prostokat otaczajacy ruchomy obiekt - poprzednia pozycja.
	@param SBox* new_dbox - Prostokat otaczajacy ruchomy obiekt - nowa pozycja.
	@param uint8_t	impact_depth_x - Glebokosc w poziomie na jaka wbilismy sie w obiekt statyczny, jesli nastapila kolizja.
	@param uint8_t	impact_depth_y - Glebokosc w pionie na jaka wbilismy sie w obiekt statyczny, jesli nastapila kolizja.
	@return bool Status kolizji.
*/
bool	box_box_collision(SBox* sbox, SBox* old_dbox, SBox* new_dbox, uint_t* impact_depth_x, uint8_t* impact_depth_y)
{
	SBox	collision_box;

	if	(new_dbox->x >= old_dbox->x)
	{
		collision_box.x = old_dbox->x + old_dbox->width - 1, collision_box.width = new_dbox->x - old_dbox->x;
		*impact_depth_x = (new_dbox->x - sbox->x) + 1;
	} else
	{
		collision_box.x = new_dbox->x, collision_box.width = old_dbox->x - new_dbox.x;
		*impact_depth_x = (sbox->x + sbox->width - new_dbox->x) + 1;
	}

	if	(new_dbox->y >= old_dbox->y)
	{
		collision_box.y = old_dbox->y + old_dbox->height - 1, collision_box.height = new_dbox->y - old_dbox->y;
		*impact_depth_y = (new_dbox->y - sbox->y) + 1;
	} else
	{
		collision_box.y = new_dbox->y, collision_box.height = old_dbox->y - new_dbox.y;
		*impact_depth_y = (sbox->y + sbox->height - new_dbox->y) + 1;
	}

	return ((collision_box.x + collision_box.width - 1) >= sbox->x) && (collision_box.x <= (sbox->x + sbox->width - 1)) &&
		((collision_box.y + collision_box.height - 1) >= sbox->y) && (collision_box.y <= (sbox->y + sbox->height - 1));
}